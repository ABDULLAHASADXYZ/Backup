<?php
// Example: Read messages from a text file
$filename = 'messages.txt';
$messages = file_get_contents($filename);

// Output messages with basic formatting (adjust as needed)
echo nl2br($messages);
?>
