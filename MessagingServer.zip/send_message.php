<?php
// Validate and sanitize inputs (adjust as needed)
$sender = filter_var($_POST['sender'], FILTER_SANITIZE_STRING);
$message = filter_var($_POST['message'], FILTER_SANITIZE_STRING);

// Example: Save messages to a text file
$filename = 'messages.txt';
$messageData = "Sender: $sender\nMessage: $message\nSent: " . date('Y-m-d H:i:s') . "\n\n";

if (file_put_contents($filename, $messageData, FILE_APPEND | LOCK_EX)) {
    http_response_code(200);
    echo "Message sent successfully.";
} else {
    http_response_code(500);
    echo "Failed to send message.";
}
?>
